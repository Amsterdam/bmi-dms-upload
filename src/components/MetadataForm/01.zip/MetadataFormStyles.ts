import styled from 'styled-components';

export const MetadataFormStyle = styled.form`
	display: flex;
	flex-direction: column;
	//margin: 10px 50px;

	h2 {
		margin-top: 0;
	}
`;
