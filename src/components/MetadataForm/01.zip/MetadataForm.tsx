import React, { ComponentProps } from 'react';
import { MetadataFormStyle } from './MetadataFormStyles';
import { JsonForms } from '@jsonforms/react';
import customRenderers from '../customRenderers';
import customLayoutRenderers from '../customLayouts';
// import { createAjv } from '@jsonforms/core';
import { materialRenderers } from '@jsonforms/material-renderers';
import MetadataColumnHeaders from '../MetadataColumnHeaders/MetadataColumnHeaders';
// import AJV from 'ajv';
import AJV from 'ajv';
import addFormats from 'ajv-formats';
import ajvErrors from 'ajv-errors';
import { Draft4 } from '@jsonforms/core/src/models/draft4';
import { createAjv } from '@jsonforms/core';
// import { createAjv } from '@jsonforms/core';
// import * as AJV from 'ajv';
// import { JsonSchema7 } from '@jsonforms/core/lib/models/jsonSchema7';

type Props = ComponentProps<typeof JsonForms> & {};

const DEFAULT_RENDERERS = [...materialRenderers, ...customRenderers, ...customLayoutRenderers];

// console.log('DEFAULT_RENDERERS', DEFAULT_RENDERERS);
// const ajv = new AJV({
// 	allErrors: true,
// 	messages: true,
// 	strict: false,
// 	// timestamp: true,
// 	ownProperties: true,
// 	verbose: true,
// });
// ajv.addMetaSchema(JsonSchema7);

// const ajv = new AJV({
// 	// schemaId: 'auto',
// 	allErrors: true,
// 	// jsonPointers: true,
// 	// errorDataPath: 'property',
// 	verbose: true,
// });
// ajv.addFormat('time', '^([0-1][0-9]|2[0-3]):[0-5][0-9]$');
// ajv.addMetaSchema(Draft4);
// // return ajv;

// const ajv = createAjv();
const ajv = new AJV({ allErrors: true });
addFormats(ajv, ['date']);

ajv.addKeyword({
	keyword: 'bmi-isNotEmpty',
	type: 'string',
	validate: function (schema: any, data: any) {
		console.log('::!!', schema, data, this);
		return typeof data === 'string' && data.trim() !== '';
	},
	errors: true,
});

// ajv.addMetaSchema(Draft4);
const ajvWithCustomErrors = ajvErrors(ajv, { keepErrors: true });

// ajv.addFormat('time', '^([0-1][0-9]|2[0-3]):[0-5][0-9]$');

// ajv.addKeyword({
// 	keyword: 'isNotEmpty',
// 	validate: function (schema: any, data: any) {
// 		return typeof data === 'string' && data.trim() !== '';
// 	},
// 	errors: false,
// });

const MetadataForm: React.FC<Props> = ({
	schema,
	uischema,
	renderers,
	data = {},
	validationMode = 'ValidateAndShow',
}) => {
	return (
		<MetadataFormStyle>
			<h2>Metadata toevoegen</h2>
			<MetadataColumnHeaders
				columns={[
					{
						header: 'Metadataveld',
						width: 50,
					},
					{
						header: 'Waarde',
						width: 50,
					},
				]}
			/>
			<JsonForms
				schema={schema}
				uischema={uischema}
				data={data}
				renderers={[...DEFAULT_RENDERERS, ...renderers]}
				validationMode={validationMode}
				onChange={({ errors, data }) => {
					console.log(':; CHANGE', errors, data);
				}}
				ajv={ajvWithCustomErrors}
			/>
		</MetadataFormStyle>
	);
};

export default MetadataForm;
